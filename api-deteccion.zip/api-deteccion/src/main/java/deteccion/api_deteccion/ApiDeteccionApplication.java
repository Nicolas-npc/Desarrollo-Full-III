package deteccion.api_deteccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDeteccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDeteccionApplication.class, args);
	}

}
