package deteccion.api_deteccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDeteccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
